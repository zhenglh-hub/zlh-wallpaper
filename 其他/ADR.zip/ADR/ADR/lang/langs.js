var langs = {
	'de':'deutsch',
	'en':'english',
	'es':'español',
	'fr':'français',
	'it':'italiano',
	'ja':'日本語',
	'ko':'한국어',
	'nb':'norsk',
	'pl':'polski',
	'pt':'português',
	'ru':'русский',
	'sv':'svenska',
	'tr':'türkçe',
	'uk':'українська',
	'vi':'tiếng việt',
	'zh_cn':'简体中文'
};
